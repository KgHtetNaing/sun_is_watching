extends Button

@export var upgrade_type: String
@export var amount_dmg: float = 8
@export var amount_size: float = 0.25
@export var amount_speed: float = 0.5

func _ready():
	pivot_offset = size / 2
	
func _on_mouse_entered() -> void:
	scale = Vector2(1.2,1.2)

func _on_mouse_exited() -> void:
	scale = Vector2(1,1)

func _on_pressed() -> void:
	match upgrade_type:
		"damage":
			GameManager.damage += amount_dmg
			print ("new damage", GameManager.damage)
		"size":
			GameManager.size += amount_size
			print("new size" , GameManager.size)
		"speed":
			GameManager.speed += amount_speed
			print("new speed" , GameManager.speed)
	
	
	#send signal to gamemanager to restart the timer
	GameManager.emit_signal("start_game_requested")
	
	#remove the UI and increase the level in gamemanager
	GameManager.current_level += 1
	print ("Current Level" , GameManager.current_level)
	remove_people()
	GameManager.reset_day()
	get_parent().queue_free()
	get_tree().change_scene_to_file("res://scenes/main_game.tscn")
	
	if GameManager.current_level >= 6:
		get_tree().call_group("main_timer" , "stop_the_clock")
		print ("stopping the timer")
	
func remove_people():
	#people.tscn is added to group("enemies")
	var people =  get_tree().get_nodes_in_group("enemies")
	for i in people:
		i.queue_free()
		

	
	
