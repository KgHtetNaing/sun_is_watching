extends Node3D


func _on_area_3d_body_entered(body: Node3D) -> void:
	print ("Sucessfully escape")
	if body.has_method("sucessfully_escape"):
		body.sucessfully_escape()
	
