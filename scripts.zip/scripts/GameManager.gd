extends Node

var day_ended = false
signal show_win_screen

var damage := 250
var size := 0.8
var speed := 0.6
var escapee = 0
var current_level = 1
var enemies_alive = 0
var round_timer = 30.0


signal start_game_requested #to restart the timer when new game start

func add_escape():
	escapee += 1
	if escapee >= 10:
		get_tree().paused = true
		get_tree().change_scene_to_file("res://lose_screen.tscn")
		
func register_enemy():
	enemies_alive += 1

func reset_day():
	day_ended = false
	enemies_alive = 0
	escapee = 0

func enemy_gone():
	enemies_alive -= 1
	print("Enemy gone, remaining: ", enemies_alive, " day_ended: ", day_ended)
	if enemies_alive <= 0 and day_ended:
		print("Emitting win screen!")
		show_win_screen.emit()
		

func start_next_level():
	current_level += 1
	# This is your loop! It forces EVERY house to update its bag of peeps.
	get_tree().call_group("houses", "on_new_level")
